# MLPro — Deploy Helper

This folder gives you ready-to-use files and instructions to deploy your **mlpro** course to **Vercel** or **GitHub Pages**.  
Your site is a single-file static app (`index.html`) with **hash-based routing**, so it works perfectly on static hosts.

---

## 1) Deploy to Vercel (no build step)

**A. Using the Dashboard (drag & drop)**
1. Go to https://vercel.com/new
2. Click **"Import..." → "Other"** or **"Deploy"** and drag the *unzipped* site contents (from `mlpro.zip`) into Vercel.
3. Add the included `vercel.json` at the project root (same folder as `index.html`).
4. Click **Deploy**. Your site will be live on a `*.vercel.app` URL.

**B. Using Git + Vercel**
1. Create a new GitHub repo and push the contents of `mlpro.zip` (unzipped) to the root.
2. Add `vercel.json` (this file) to the root of that repo.
3. In Vercel, **"Add New Project" → "Import from Git"**, select your repo, and **Deploy**.

**Optional:** Set a custom domain in Vercel → Project → **Settings → Domains**.

---

## 2) Deploy to GitHub Pages (no build step)

**A. Using the GitHub UI**
1. Create a new repository (e.g., `mlpro`).
2. Upload the contents of `mlpro.zip` (unzipped) to the root of the repo.
3. Add the included `.nojekyll` file (prevents Jekyll processing) at the root.
4. Go to **Settings → Pages**:
   - **Source:** `Deploy from a branch`
   - **Branch:** `main` (or `master`) and `/ (root)`
   - Click **Save**. GitHub will give you a live URL: `https://<username>.github.io/<repo>/`
5. Since we use **hash-based routing**, no extra 404 rewrite is required. (We still include a minimalist `404.html` as a safety net.)

**B. Using CLI**
```bash
# inside your project folder that contains index.html
git init
git add .
git commit -m "Launch mlpro site"
git branch -M main
gh repo create mlpro --public --source=. --remote=origin --push  # requires GitHub CLI
git push -u origin main
# Enable Pages in the repo: Settings → Pages → set Branch to main / root
```

---

## 3) FAQ

**Q: Will people see my code?**  
Yes. Static hosts always expose HTML/JS/CSS to the browser. If you need to keep logic private, move auth/paywall to a backend.

**Q: Do I need build tools?**  
No. This site is a single `index.html` and runs as-is.

**Q: My video says 'unavailable'**  
Some videos disallow embedding in certain regions. Swap the `videoUrl` for that topic to another YouTube ID that allows embeds. We’ve already picked embed-friendly links, but replacements are straightforward in `index.html`.

**Q: Custom domain?**  
- **Vercel:** Project → Settings → Domains → Add. Update your DNS with the shown CNAME records.
- **GitHub Pages:** Settings → Pages → Custom domain; then add a `CNAME` DNS record pointing to `<username>.github.io`.

**Last updated:** 2025-08-15
